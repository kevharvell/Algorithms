Name: Kevin Harvell
Date: 1/19/19
Class: CS325-400
Assignment: HW #2

To compile and run the programs, enter into terminal:

python mergesort4.py
python merge4Time.py