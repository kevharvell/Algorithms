Name: Kevin Harvell
Date: 2/2/19
Class: CS325-400
Assignment: HW #2

To compile and run the programs, enter into terminal:

python activity.py