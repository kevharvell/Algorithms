Name: Kevin Harvell
Date: 1/12/19
Class: CS325-400
Assignment: HW #1

To compile and run the programs, enter into terminal:

python insertsort.py
python mergesort.py
python insertTime.py
python mergeTime.py