Name: Kevin Harvell
Date: 1/27/19
Class: CS325-400
Assignment: HW #3

To compile and run the program(s), enter into terminal:

python shopping.py